package tr.com.mahmutbulut.interfaces;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JMenuBar;

public interface FeInterfaces {
	
	public void initPencere();
	public JPanel initPanel();
	public JMenuBar initBar();
	public JTabbedPane initTabs();
	

}

package tr.com.mahmutbulut.interfaces;

import java.sql.Connection;

public interface CoreInterfaces {

	public Connection getConnection();

}

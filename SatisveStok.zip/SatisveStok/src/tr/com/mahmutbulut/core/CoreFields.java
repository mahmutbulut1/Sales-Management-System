package tr.com.mahmutbulut.core;

public class CoreFields {

	private String userName = "root";
	private String password = "170419040";
	private String url = "jdbc:mysql://localhost/satisvestok?useUnicode=true&characterEncoding=UTF-8";

	public String getUserName() {
		return userName;
	}

	public String getPassword() {
		return password;
	}

	public String getUrl() {
		return url;
	}

}
